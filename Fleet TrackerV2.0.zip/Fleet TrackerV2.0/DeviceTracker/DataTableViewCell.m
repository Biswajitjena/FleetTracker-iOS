//
//  DataTableViewCell.m
//  DeviceTracker
//
//  Created by Dhara on 27/01/16.
//  Copyright © 2016 Net4Nuts. All rights reserved.
//

#import "DataTableViewCell.h"

@implementation DataTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
