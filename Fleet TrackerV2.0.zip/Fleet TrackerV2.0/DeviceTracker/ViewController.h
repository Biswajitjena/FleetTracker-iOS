//
//  ViewController.h
//  DeviceTracker
//
//  Created by Dhara on 22/12/15.
//  Copyright © 2015 Net4Nuts. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DBmanager.h"

@interface ViewController : UIViewController<UIAlertViewDelegate>

- (IBAction)btninfo:(id)sender;


@end

